import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './styles.css'

try {
  const theme = localStorage.getItem('estuda.theme')
  if (theme === 'light' || theme === 'dark') document.documentElement.setAttribute('data-theme', theme)
} catch { /* sem armazenamento */ }

createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>)
